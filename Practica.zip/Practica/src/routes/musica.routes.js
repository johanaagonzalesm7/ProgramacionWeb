import {Router} from 'express'
import pool from '../database.js'

const router = Router();

router.get('/add', (req, res)=>{
    res.render('musica/add');
});

router.post('/add', async(req, res)=>{
    try{
        const {song, artist, genre, year, record_company} = req.body;
        const newMusica = {
            song, artist, genre, year, record_company
        }
        await pool.query('INSERT INTO musica SET ?', [newMusica]);
        res.redirect('/list');
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/list', async(req, res)=>{
    try{
        const [result] = await pool.query('SELECT * FROM musica');
        res.render('musica/list', {musica: result});
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/edit/:id', async(req, res)=>{
    try{
        const {id} = req.params;
        const [musica] = await pool.query('SELECT * FROM musica WHERE id = ?', [id]);
        const musicaEdit = musica[0];
        res.render('musica/edit',{musica: musicaEdit});
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
});

router.post('/edit/:id', async(req, res)=>{
    try{
        const {song, artist, genre, year, record_company} = req.body;
        const {id} = req.params;
        const editMusica = {song, artist, genre, year, record_company};
        await pool.query('UPDATE musica SET ? WHERE id=?', [editMusica, id]);
        res.redirect('/list')
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/delete/:id', async(req, res)=>{
    try{
        const {id} = req.params;
        await pool.query('DELETE FROM musica WHERE id = ?', [id]); 
        res.redirect('/list');
    }
    catch(err){
        res.status(500).json({message:err.message});
    }
});

export default router