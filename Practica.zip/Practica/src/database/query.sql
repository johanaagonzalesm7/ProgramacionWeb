CREATE DATABASE disqueras;

USE disqueras;

CREATE TABLE musica(
    id INT AUTO_INCREMENT PRIMARY KEY,
    song VARCHAR(50) NOT NULL,
    artist VARCHAR(50) NOT NULL,
    genre VARCHAR(50) NOT NULL,
    year INT,
    record_company VARCHAR(60) NOT NULL
);

SELECT * FROM musica;